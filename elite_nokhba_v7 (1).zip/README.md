# نُخبة — حزمة الإنتاج (v7)

تطبيق **نُخبة** لتوقعات مباريات الدوري الإنجليزي الممتاز (PWA متوافق مع Median / WebView / iOS / Android / المتصفحات).

## محتويات الحزمة

| الملف | الوصف |
|---|---|
| `index.html` | التطبيق الكامل (الواجهة + منطق Supabase + OAuth + تسجيل Service Worker). **كامل وغير مبتور — 753,865 بايت / 16,342 سطر.** |
| `sw.js` | Service Worker — Network-First للـ HTML + navigationPreload + Stale-While-Revalidate للأصول + مهلة 12s + معالجة صامتة للأخطاء العابرة. |
| `sw-register.js` | منطق تسجيل احتياطي مستقل (التسجيل الأساسي مدمج داخل `index.html`). آمن ضد التسجيل المزدوج. |
| `manifest.json` | بيان PWA (اسم نُخبة، أيقونات، theme-color، standalone، RTL). |
| `vercel.json` | رؤوس النشر: `no-store` للـ HTML/SW + كاش سنة للأصول + rewrites. |
| `icon-192.png` / `icon-512.png` | أيقونات التطبيق. |
| `.github/workflows/deploy.yml` | نشر تلقائي إلى Vercel عند الدفع إلى `main`. |

## كيف تعمل آلية التحديث التلقائي

1. `index.html` يسجّل `sw.js` ويستدعي `reg.update()` عند التحميل، كل دقيقتين، وعند عودة التطبيق للمقدمة.
2. `sw.js` يُجلب دائماً بـ `no-store` (مضمون عبر `vercel.json` + داخل الـ SW نفسه) → يُكتشف أي نسخة جديدة فوراً.
3. عند اكتشاف نسخة جديدة → `SKIP_WAITING` → `controllerchange` → إعادة تحميل واحدة فقط (محمية بفاصل 60 ثانية لمنع حلقات الإعادة).

**النتيجة:** يصل التحديث للمستخدم تلقائياً — بدون مسح كاش، بدون إعادة تثبيت، بدون احتجاز على نسخة قديمة.

## النشر على Vercel

```bash
npm i -g vercel
vercel --prod
```

أو ادفع إلى GitHub بعد ضبط أسرار `VERCEL_TOKEN` / `VERCEL_ORG_ID` / `VERCEL_PROJECT_ID` فيعمل `deploy.yml` تلقائياً.

## ملاحظات أمنية
- المفتاح المستخدم في `index.html` هو **anon key** (آمن في الواجهة) بشرط: تفعيل RLS على كل جداول Supabase، وعدم استخدام `service_role` في الواجهة، وتقييد allowed origins.

## التوافق
Chrome · Safari iOS · Samsung Internet · Edge · Firefox · WebView (Median / Natively) — بدون VPN.
